public class MatrixNotPossibleException extends Exception {

    public MatrixNotPossibleException() {
        super("Erro! metodo so pode ser usado em matriz quadradas!");
    }

}
