import Classes.Carro;

public class Teste {
    public static void main(String[] args) throws Exception {
        Carro c1 = new Carro(5000, 2000, 5);

        c1.andar(1001);
    }
}
